import { LoginPage } from "@/app/views/LoginPage/LoginPage";
import { RegisterPage } from "@/app/views/RegisterPage/RegisterPage";


export default function Register() {
    return (
        <RegisterPage />
    )
}