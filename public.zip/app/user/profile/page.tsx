"use client";

import { ProfilePage } from "@/app/views/ProfilePage/ProfilePage";


export default function Profile() {


  return (
    <ProfilePage />
  );
}